import { useState } from 'react'
import './App.css'
import LandingPage from './components/Landingpage/LandingPage'
import StudentPortal from './components/studentportal/StudentPortal'

function App() {
  return (
    <>
      <LandingPage />
      <StudentPortal/>
    </>
  )
}

export default App
