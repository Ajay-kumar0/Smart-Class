import React from "react";
import teacherpng from "../../assets/clipart1488117.png";
import studentpng from "../../assets/student194931.png";
import smartpng from "../../assets/smartclass.png";
import "./LandingPage.css";

const landingPage = () => {
  return (
    <div className="main">
      <img src={smartpng} alt="Smart Class" />

      <div className="container">
        <div className="slogin">
          <h3>I'm Student</h3>
          <img src={studentpng} alt="student" />
          <button>Student Portal</button>
        </div>

        <div className="tlogin">
          <h3>I'm Teacher</h3>
          <img src={teacherpng} alt="teacher" />
          <button>Teacher Portal</button>
        </div>
      </div>
    </div>
  );
};

export default landingPage;
