import React from 'react'
import smartpng from "../../assets/smartclass.png";

const Logo = () => {
  return (
    <div>
        <img src={smartpng} alt="logo" style={ "margin-bottom: 50px"}/>
    </div>
  )
}

export default Logo