import React from 'react'
import LoginSt from './login/LoginSt'


const StudentPortal = () => {
  return (
    <div>
        <LoginSt />
    </div>
  )
}

export default StudentPortal