import React from 'react'
import './LoginSt.css'

const LoginSt = () => {
  return (
    <div className="login-page">
    <div className="login-card">
        <h1>Login Using Password</h1>

        <div className="input-group">
            <label>Username</label>
            <input type="text" placeholder="Enter your username" />
        </div>

        <div className="input-group">
            <label>Password</label>
            <input type="password" placeholder="Enter your password" />
        </div>

        <div className="button-group">
            <button className="login-btn">Login</button>
            <button className="register-btn">Register Instead</button>
        </div>
    </div>
</div>
  )
}

export default LoginSt